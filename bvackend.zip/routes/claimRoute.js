// claimRoutes.js
const express = require("express");
const router = express.Router();
const claimController = require("../controllers/claimController");
const authController = require("../controllers/authController");

router.post(
  "/:policyEnrollmentId",
  authController.protect,
  claimController.createClaim
);

module.exports = router;
